/*
 ============================================================================
 Name        : serverUDP.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <string.h>
#include "prot_appl.h"
#include "math.h"

#define NO_ERROR 0
void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

int main(int argc, char *argv[]) {
	setvbuf(stdout, NULL, _IONBF, 0);

#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	char server_message[BUFF], client_message[BUFF];

	// Clean buffers
	memset(server_message, '\0', sizeof(server_message));
	memset(client_message, '\0', sizeof(client_message));

	//Create a socket
	int server_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (server_socket < 0) {
		printf("socket creation failed.\n");
		clearwinsock();
		return -1;
	}

	// Set port and IP:
	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	if (argc > 1) {
		server_addr.sin_port = htons(atoi(argv[1]));
	} else {
		server_addr.sin_port = htons(PROTOPORT);
	}


	// Bind to the set port and IP
	if (bind(server_socket, (struct sockaddr*) &server_addr,
			sizeof(server_addr)) < 0) {
		printf("bind() failed.\n");
		closesocket(server_socket);
		clearwinsock();
		return -1;
	}
	printf("Waiting for a request....\n\n");
	while (1) {
		// Reiceve client message
		struct sockaddr_in client_addr;
		int client_addr_lenght = sizeof(client_addr);
		if (recvfrom(server_socket, client_message, sizeof(client_message), 0,
				(struct sockaddr*) &client_addr, &client_addr_lenght) < 0) {
			printf("Couldn't receive\n\n");
			return -1;
		}



		// Get host name by address
		struct in_addr addr;
		addr.s_addr =client_addr.sin_addr.s_addr;

		struct hostent *client_host = gethostbyaddr((char *) &addr, 4, AF_INET);
		printf("Requested operation '%s' from client %s , ip  %s\n",
				client_message, client_host->h_name ,
				inet_ntoa(client_addr.sin_addr));


		// Splitting client message into tokens"
		char *token;
		char *string_set[2];
		token = strtok(client_message, " ");
		int i = 0;
		while (token != NULL) {
			string_set[i] = token;
			i++;
			token = strtok(NULL, " ");
		}

		char operator = string_set[0][0];
		int operand1 = atoi(string_set[1]); //Convert string into integer
		int operand2 = atoi(string_set[2]);
		float solution = 0;

		switch (operator) {
		case '+':
			solution = add(operand1, operand2);
			break;
		case '*':
			solution = mult(operand1, operand2);
			break;

		case '-':
			solution = sub(operand1, operand2);
			break;

		case '/':
			solution = division(operand1, operand2);
			break;

		}

		// Convert float into string
		char string_solution[20];
		gcvt(solution, 6, string_solution);

		//Concatenate multiple strings
		strcpy(server_message, string_set[1]);
		strcat(server_message, " ");
		strcat(server_message, string_set[0]);
		strcat(server_message, " ");
		strcat(server_message, string_set[2]);
		strcat(server_message, " = ");
		strcat(server_message, string_solution);

		if (sendto(server_socket, server_message, strlen(server_message), 0,
				(struct sickaddr*) &client_addr, client_addr_lenght) < 0) {
			printf("Can't send\n");
			return -1;
		}
		// Clean buffers
		memset(server_message, '\0', sizeof(server_message));
		memset(client_message, '\0', sizeof(client_message));
	}
	return 0;
}


