/*
 ============================================================================
 Name        : clientUDP.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <string.h>
#include "prot_appl.h"

#define NO_ERROR 0
void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

int main(int argc, char *argv[]) {
	setvbuf(stdout, NULL, _IONBF, 0);

#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	char server_message[BUFF], client_message[BUFF];

	// Clean buffers
	memset(server_message, '\0', sizeof(server_message));
	memset(client_message, '\0', sizeof(client_message));

	//Create a socket
	int client_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (client_socket < 0) {
		printf("socket creation failed.\n");
		clearwinsock();
		return -1;
	}

	// Set port and IP the same as server-side
	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	if (argc > 1) {

		// Splitting name and port"
		char *token;
		char *string_set[1];
		token = strtok(argv[1], ":");
		int i = 0;
		while (token != NULL) {
			string_set[i] = token;
			i++;
			token = strtok(NULL, ":");
		}
		struct hostent *server_host = gethostbyname(string_set[0]);
		struct in_addr *addr;

		if (server_host == NULL) {
			fprintf(stderr, "gethostbyname() failed.\n");
			exit(EXIT_FAILURE);
		} else {
			addr = (struct in_addr*) server_host->h_addr_list[0];
		}


		server_addr.sin_addr.s_addr = inet_addr(inet_ntoa(*addr));
		server_addr.sin_port = htons(atoi(string_set[1]));

	} else {
		server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
		server_addr.sin_port = htons(PROTOPORT);
	}
	int server_addr_lenght = sizeof(server_addr);

	while (1) {

		/* To do control on input I have to use a regular expression but at
		 * the end of this exercise, I decided to not do it. Also because
		 * it is not specified on track of the exercise.
		 * So use only the correct pattern for inputs
		 */

		// Get input from the user
		printf(	"Insert an operation with this pattern: [operator] [num] [num] (ex. + 2 4).\n"
					"Valid operators are: + - * /.\n"
					"To close connection insert: =.\n"
					"Input:");
		gets(client_message);

		//Exit
		if (client_message[0] == '=') {
			break;
		}

		//Send the message to server
		if (sendto(client_socket, client_message, strlen(client_message), 0,
				(struct sockaddr*) &server_addr, &server_addr_lenght) < 0) {
			printf("Unable to send message\n");
			system("pause");
			closesocket(client_socket);
			clearwinsock();
			return -1;
		}

		// Receive the server's response
		if (recvfrom(client_socket, server_message, sizeof(server_message), 0,
				(struct sockaddr*) &server_addr, &server_addr_lenght) < 0) {
			printf("Error while receiving server's msg\n");
			closesocket(client_socket);
			clearwinsock();
			return -1;
		}

		struct in_addr addr;
		addr.s_addr = server_addr.sin_addr.s_addr;
		struct hostent *server_host = gethostbyaddr((char*) &addr, 4, AF_INET);
		printf("Received result from %s , ip  %s: %s\n\n",
				server_host->h_name, inet_ntoa(server_addr.sin_addr),
				server_message);

		// Clean buffers
		memset(server_message, '\0', sizeof(server_message));
		memset(client_message, '\0', sizeof(client_message));

	}

	//Close socket
	closesocket(client_socket);
	clearwinsock();
	printf("\n"); // Print a final linefeed
	system("pause");
	return (0);

} //end main

