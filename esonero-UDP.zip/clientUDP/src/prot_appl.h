/*
 * prot_appl.h
 *
 *  Created on: 16 dic 2021
 *      Author: cecca
 */

#ifndef PROT_APPL_H_
#define PROT_APPL_H_

#define BUFF 256
#define PROTOPORT 27015

#endif /* PROT_APPL_H_ */
